package com.example.myfirstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView txt;
    Button red_btn;
    Button blue_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void changeColorBlueButton(View view){
        blue_btn = findViewById(R.id.blue_button);
        blue_btn.setBackgroundColor(Color.BLUE);
        txt = findViewById(R.id.textView);
        txt.setBackgroundColor(Color.BLUE);
        txt.setText("blue");
        Toast.makeText(this, "blue button click", Toast.LENGTH_LONG).show();
    }

    public void changeColorRedButton(View view){
        red_btn = findViewById(R.id.red_button);
        red_btn.setBackgroundColor(Color.RED);
        txt = findViewById(R.id.textView);
        txt.setBackgroundColor(Color.RED);
        txt.setText("red");
        Toast.makeText(this, "red button click", Toast.LENGTH_LONG).show();
    }
}